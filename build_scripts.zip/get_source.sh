#!/bin/bash

set -e

git config --global credential.helper '!aws codecommit credential-helper $@'
git config --global credential.UseHttpPath true
git clone --single-branch --branch $BRANCH_NAME https://git-codecommit.ca-central-1.amazonaws.com/v1/repos/${REPOSITORY_NAME}

cd $REPOSITORY_NAME
SHORT_VERSION_HASH=`git rev-parse --short HEAD`
export BRANCH_AND_REVISION=$BRANCH_NAME.$SHORT_VERSION_HASH
cd ..