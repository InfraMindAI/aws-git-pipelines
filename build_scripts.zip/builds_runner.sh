#!/bin/bash

IS_DEBUG=true
set -e

printArray() {
  if $IS_DEBUG
  then
    echo '--------------------------'
    echo $1

    shift 1
    array=("$@")

    for var in "${array[@]}"
    do
      echo "${var}"
    done
  fi
}

# -------------------------------------------------------------------
# get changelist
# -------------------------------------------------------------------

CHANGES=($(git diff --name-only HEAD^1 HEAD))

printArray "Changed files:" "${CHANGES[@]}"

# -------------------------------------------------------------------
# remove filenames from paths
# -------------------------------------------------------------------

SRC_DIR=`pwd`
for i in "${!CHANGES[@]}"; do
  DIRNAME=`dirname "${CHANGES[$i]}"`
  CHANGES[$i]="$SRC_DIR/$DIRNAME"
done

# -------------------------------------------------------------------
# leave only unique dirs, which exist: if N files changed in the same dir
# we want to search for build.sh in this directory only once
# -------------------------------------------------------------------

UNIQUE_FOLDERS=()
for i in "${!CHANGES[@]}"; do
  CURRENT_PATH="${CHANGES[$i]}"

  if [ -d $CURRENT_PATH ]; then  
    is_same=false

    for j in "${!UNIQUE_FOLDERS[@]}"; do
      if [[ $CURRENT_PATH == "${UNIQUE_FOLDERS[$j]}" ]]; then
        is_same=true
        break
      fi
    done
    
    if [ $is_same = false ] ; then
      UNIQUE_FOLDERS=("${UNIQUE_FOLDERS[@]}" $CURRENT_PATH)
    fi
  fi
done

printArray "Unique folders:" "${UNIQUE_FOLDERS[@]}"

# -------------------------------------------------------------------
# Search for build.sh in current folder and its parent folders
# until we find it.
# -------------------------------------------------------------------

BUILD_SCRIPTS_PATHS=()
for i in "${!UNIQUE_FOLDERS[@]}"; do
  path=${UNIQUE_FOLDERS[$i]}
  echo "--"
  while :
  do
      if $IS_DEBUG
      then
        echo "searching build.sh in $path"
      fi

      BUILD_SCRIPT_PATH=`find "$path" -maxdepth 1 -mindepth 1 -name build.sh`
      
      if [[ -n $BUILD_SCRIPT_PATH ]]
      then
        BUILD_SCRIPTS_PATHS=("${BUILD_SCRIPTS_PATHS[@]}" "${BUILD_SCRIPT_PATH}")
        break;
      fi
      
      if [[ $path -ef $SRC_DIR ]]
      then
        break;
      fi

      path="$(realpath -s "$path"/..)"
  done
done

printArray "Paths to build scripts:" "${BUILD_SCRIPTS_PATHS[@]}"

# -------------------------------------------------------------------
# leave only unique build scripts: if different folders will produce
# the same build script on prev step, we want to run script only once
# -------------------------------------------------------------------

UNIQUE_BUILD_SCRIPTS_PATHS=()
for i in "${!BUILD_SCRIPTS_PATHS[@]}"; do
  is_same=false

  for j in "${!UNIQUE_BUILD_SCRIPTS_PATHS[@]}"; do
    if [[ "${BUILD_SCRIPTS_PATHS[$i]}" == "${UNIQUE_BUILD_SCRIPTS_PATHS[$j]}" ]]; then
      is_same=true
      break
    fi
  done
  
  if [ $is_same = false ] ; then
    UNIQUE_BUILD_SCRIPTS_PATHS=("${UNIQUE_BUILD_SCRIPTS_PATHS[@]}" "${BUILD_SCRIPTS_PATHS[$i]}")
  fi
done

printArray "Unique build scripts:" "${UNIQUE_BUILD_SCRIPTS_PATHS[@]}"

# -------------------------------------------------------------------
# run all found build scripts
# -------------------------------------------------------------------

for i in "${!UNIQUE_BUILD_SCRIPTS_PATHS[@]}"; do
  BUILD_SCRIPT_PATH=${UNIQUE_BUILD_SCRIPTS_PATHS[$i]}
  echo "Executing <$BUILD_SCRIPT_PATH>:"
  DIRNAME=`dirname "${BUILD_SCRIPT_PATH}"`
  cd $DIRNAME
  bash ./build.sh
done
