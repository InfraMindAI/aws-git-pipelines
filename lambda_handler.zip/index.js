const AWS = require('aws-sdk');
const CODEPIPELINE = new AWS.CodePipeline();
const ACCOUNT_ID = '123456'; //your AWS account id here
const BUILD_BUCKET = ''; //your build bucket name here

exports.handler = function(event, context, callback) {
  console.log("EVENT: " + JSON.stringify(event));

  var repositoryName = event.detail.repositoryName != null ? event.detail.repositoryName : event.detail.repositoryNames[0];
  var referenceName = event.detail.referenceName != null ? event.detail.referenceName : event.detail.destinationReference.substring(event.detail.destinationReference.lastIndexOf("/") + 1);
  var eventType = event.detail.event != null ? event.detail.event : "";
  var pipelineName = "git-" + repositoryName + "-" + referenceName;
  
  switch(eventType) {
    case "referenceCreated":
      createPipeline(repositoryName, referenceName, pipelineName);
      break;
    case "referenceUpdated":
      startPipeline(pipelineName);
      break;
    case "referenceDeleted":
      deletePipeline(pipelineName);
      break;
    default:
      console.log("Skipping event: " + eventType);
  }
};

function createPipeline(repositoryName, referenceName, pipelineName) {
  var environmentVariables = [
    {
      name: 'REPOSITORY_NAME',
      type: 'PLAINTEXT',
      value: repositoryName
    }, {
      name: 'BRANCH_NAME',
      type: 'PLAINTEXT',
      value: referenceName
    }
  ];
  
  var params = {
    pipeline: {
      name: pipelineName,
      roleArn: 'arn:aws:iam::' + ACCOUNT_ID + ':role/git-codepipeline-role',
      stages: [
        {
          name: 'Source',
          actions: [
            {
              name: 'Source',
              actionTypeId: {
                category: 'Source',
                owner: 'AWS',
                provider: 'S3',
                version: '1'
              },
              runOrder: '1',
              configuration: {
                'PollForSourceChanges': 'false',
                'S3Bucket': BUILD_BUCKET,
                'S3ObjectKey': 'git_pipelines/build_scripts.zip'
              },
              outputArtifacts: [
                {
                  name: 'source_output'
                }
              ],
              inputArtifacts: []
            }
          ]
        },
        {
          name: 'Build',
          actions: [
            {
              name: 'Build',
              actionTypeId: {
                category: 'Build',
                owner: 'AWS',
                provider: 'CodeBuild',
                version: '1'
              },
              runOrder: '1',
              configuration: {
                'EnvironmentVariables': JSON.stringify(environmentVariables),
                'ProjectName': 'git-codebuild-project'
              },
              outputArtifacts: [],
              inputArtifacts: [                {
                  name: 'source_output'
                }
              ]
            }
          ]
        }
      ],
      artifactStore: {
        type: 'S3',
        location: BUILD_BUCKET
      }
    }
  };
  
  CODEPIPELINE.createPipeline(params, function(err, data) {
      console.log(err
        ? "cannot create pipeline <" + pipelineName + ">. Reason: " + err
        : "successfully created <" + pipelineName + ">"
      );
  });
}

function startPipeline(pipelineName) {
  var params = {
      name: pipelineName
  };

  CODEPIPELINE.startPipelineExecution(params, function(err, data) {
      console.log(err
        ? "cannot run pipeline <" + pipelineName + ">. Reason: " + err
        : "successfully run <" + pipelineName + ">"
      );
  });
}

function deletePipeline(pipelineName) {
  var params = {
      name: pipelineName
  };

  CODEPIPELINE.deletePipeline(params, function(err, data) {
      console.log(err
        ? "cannot delete pipeline <" + pipelineName + ">. Reason: " + err
        : "successfully deleted <" + pipelineName + ">"
      );
  });
}